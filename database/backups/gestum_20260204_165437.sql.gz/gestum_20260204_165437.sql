/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.27-MariaDB, for Linux (x86_64)
--
-- Host: 172.30.80.1    Database: gestum
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `baixas_parciais`
--

DROP TABLE IF EXISTS `baixas_parciais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `baixas_parciais` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `lancamento_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conta_bancaria_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor_pago` decimal(15,2) NOT NULL,
  `data_pagamento` date NOT NULL,
  `metodo_pagamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `baixas_parciais_user_id_foreign` (`user_id`),
  KEY `baixas_parciais_lancamento_id_foreign` (`lancamento_id`),
  KEY `baixas_parciais_conta_bancaria_id_foreign` (`conta_bancaria_id`),
  KEY `baixas_parciais_data_pagamento_index` (`data_pagamento`),
  CONSTRAINT `baixas_parciais_conta_bancaria_id_foreign` FOREIGN KEY (`conta_bancaria_id`) REFERENCES `conta_bancaria` (`id`),
  CONSTRAINT `baixas_parciais_lancamento_id_foreign` FOREIGN KEY (`lancamento_id`) REFERENCES `lancamentos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `baixas_parciais_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `baixas_parciais`
--

LOCK TABLES `baixas_parciais` WRITE;
/*!40000 ALTER TABLE `baixas_parciais` DISABLE KEYS */;
/*!40000 ALTER TABLE `baixas_parciais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bancos`
--

DROP TABLE IF EXISTS `bancos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bancos` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bancos`
--

LOCK TABLES `bancos` WRITE;
/*!40000 ALTER TABLE `bancos` DISABLE KEYS */;
INSERT INTO `bancos` VALUES ('019c1e87-3801-72ea-9e8c-4b7361de42d0','Banco do Brasil S.A.','001','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3817-7273-8abb-6b80962ffbe6','Banco da Amazônia S.A.','003','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-382e-7245-bc48-660ae267a9ad','Banco do Nordeste do Brasil S.A.','004','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-383b-7065-9431-5c7aa3b3c4eb','Banco Nacional de Desenvolvimento Econômico e Social - BNDES','007','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3848-739d-b0d0-5afd37f69210','Banco Inbursa S.A.','012','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3855-73bf-9d0f-436cc77c3b52','BANESTES S.A. Banco do Estado do Espírito Santo','021','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3863-7373-99ab-60b718d11c37','Banco de Pernambuco S.A. - BANDEPE','024','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3870-729b-b49d-3fc9acb03253','Banco Alfa S.A.','025','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-387e-72b6-9089-99451bd09206','Banco Itaú Consignado S.A.','029','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3892-712a-8bdc-db2c7c17386f','Banco Santander (Brasil) S.A.','033','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-389f-72ea-b69d-e0206195507b','Banco Bradesco BBI S.A.','036','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-38b4-7092-8d38-98c2d1178030','Banco do Estado do Pará S.A.','037','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-38c2-70e7-b9c2-d822b1ddf471','Banco Cargill S.A.','040','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-38cf-728e-81f9-ea8a2da45d3d','Banco do Estado do Rio Grande do Sul S.A. (Banrisul)','041','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-38dd-7204-b10f-e8df92e17bed','Banco do Estado de Sergipe S.A.','047','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-38ea-733f-b7c0-05cb3644cba3','Hipercard Banco Múltiplo S.A.','062','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-38fe-7267-b306-add8afae53b8','Banco Bradescard S.A.','063','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3914-71e7-be0b-029c0f48750b','Banco Andbank (Brasil) S.A.','065','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-392a-70f8-b76b-f50d5dad37d5','Banco Morgan Stanley S.A.','066','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-393f-71da-90c6-e81650468cfa','Banco Crefisa S.A.','069','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-394e-725e-9a86-a52b2225d32e','BRB - Banco de Brasília S.A.','070','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3962-717c-b03f-358e57635f68','Banco J. Safra S.A.','074','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-396f-71dc-8f79-4ee1ee72a0d7','Banco ABN Amro S.A.','075','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-397d-7388-8f2f-1309f22bfe73','Banco Inter S.A.','077','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-398a-72f0-afd8-2908859d738f','Banco Topázio S.A.','082','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3997-734a-bdbb-cbe1443eea8c','Banco da China Brasil S.A.','083','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-39a5-716b-92ba-c42ae23447a2','Banco Finaxis S.A.','094','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-39b3-731c-a708-c1e1b2eacbac','Banco Travelex S.A.','095','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-39c7-715e-a274-128a84d901cd','Banco B3 S.A.','096','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-39d5-73f1-8526-f92d556b8be4','Banco XP S.A.','102','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-39e2-70b4-9af9-505472ec1dff','Caixa Econômica Federal','104','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-39fb-72d3-b5aa-bdc947cae5da','Banco BOCOM BBM S.A.','107','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3a10-71b9-9fd8-c65757a68b98','Banco Western Union do Brasil S.A.','119','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3a26-7338-99ae-254189091e34','Banco Rodobens S.A.','120','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3a39-7004-81d4-86a6e30dd265','Banco Agibank S.A.','121','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3a47-7266-8eac-baf1597c3382','Banco Genial S.A.','125','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3a7a-735d-a63c-0b20273f8b8b','Braza Bank S.A. Banco de Câmbio','128','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3a87-7123-ab5d-6d16f93e1036','UBS Brasil Banco de Investimento S.A.','129','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3a96-711e-ac82-a739bd08ad19','Ebury Banco de Câmbio S.A.','144','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3aa6-70a6-9576-35e2e300d640','Banco Olé Bonsucesso Consignado S.A.','169','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3abb-7253-9671-60103de4cb60','Banco Itaú BBA S.A.','184','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3ac9-72f3-be5a-c58ea3ac131c','Banco Bradesco Cartões S.A.','204','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3ad6-7274-8ba0-97cdb990dac3','Banco BTG Pactual S.A.','208','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3ae9-73dc-941e-2b98f469d8a4','Banco Original S.A.','212','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3af5-7319-bb1e-802e4b737a00','Banco John Deere S.A.','217','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3b04-7059-a914-bc08e059ad18','Banco BS2 S.A.','218','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3b11-72bb-96f1-b5053f8d2a6a','Banco Credit Agricole Brasil S.A.','222','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3b1e-70c3-a0af-f8c03a4430c0','Banco Fibra S.A.','224','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3b2d-7045-8bd6-190cced4ea26','Banco Cifra S.A.','233','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3b3a-7348-ac37-45bade5666d2','Banco Bradesco S.A.','237','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3b4c-702c-ab07-40ea1882210c','Banco Master S.A.','243','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3b5c-7142-b9c0-f37d834eefd1','Banco ABC Brasil S.A.','246','2026-02-02 13:25:04','2026-02-02 13:25:04'),('019c1e87-3b70-7065-a466-c7d81f93036e','Banco Investcred Unibanco S.A.','249','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3b7d-7154-96be-5b71abb0edcd','BCV - Banco de Crédito e Varejo S.A.','250','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3b8a-7129-b778-fd73e8efdd98','Paraná Banco S.A.','254','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3b97-7271-a3f4-1da5446585d8','Nu Pagamentos S.A. (Nubank)','260','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3ba4-7270-b5e3-e308a8d542a0','Banco Fator S.A.','265','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3bb9-728b-955c-5f79e3b4a33f','Banco HSBC S.A.','269','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3bc6-715e-af08-d9efdbc3beb2','Pagseguro Internet S.A.','290','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3bd3-70b1-9fc9-175881466165','Banco Afinz S.A. Banco Múltiplo','299','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3be0-7379-bbdb-7f151069ef6f','Banco BMG S.A.','318','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3bee-7163-a101-ccf35a87298f','Bank Of China (Brasil) Banco Múltiplo S.A.','320','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3bfc-7156-9838-30f769128e88','Banco C6 S.A.','336','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c0a-7099-865b-ad8195908064','Itaú Unibanco S.A.','341','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c1d-7196-895c-2538cf50014c','Banco XP S.A.','348','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c2a-71cc-a0a6-84d9c0fbcd83','Banco Société Générale Brasil S.A.','366','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c37-7209-abcd-fbea41422b47','Banco Mizuho do Brasil S.A.','370','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c45-72a8-92dc-0b45ef4ca1d0','Banco J. P. Morgan S.A.','376','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c52-713c-96c1-11089bf5158b','Nu Financeira S.A.','386','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c60-7267-9f86-826e33e38d8d','Banco Mercantil do Brasil S.A.','389','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c6c-73d5-8ef0-419a50d6c4d5','Banco Bradesco Financiamentos S.A.','394','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c86-7063-9528-377899b649a0','Kirton Bank S.A. - Banco Múltiplo','399','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3c9c-70f7-8995-2e3b2b9b3fa9','Banco Capital S.A.','412','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3caf-707a-a708-13761b0db320','Banco Safra S.A.','422','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3cbb-703e-a549-e58ab11f7511','Banco MUFG Brasil S.A.','456','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3cc9-700b-a4c7-27b165659c12','Banco Sumitomo Mitsui Brasileiro S.A.','464','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3cdc-73c0-90be-f12d39f56b3a','Banco Caixa Geral - Brasil S.A.','473','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3ce9-719f-81b3-40582c1e91e4','Citibank N.A.','477','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3cf7-7102-b234-9be183c0dd19','Banco ItauBank S.A','479','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d04-7203-80c9-a32ec24e7304','Deutsche Bank S.A. - Banco Alemão','487','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d12-7028-bcef-0024304ec9db','JPMorgan Chase Bank, National Association','488','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d21-70a3-aa5c-77ff0f083cee','BBVA Brasil Banco de Investimento S.A.','496','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d2e-705e-ad88-25de364737b4','Banco Credit Suisse (Brasil) S.A.','505','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d41-71f0-8c69-6e2ad6a5da6e','Banco Luso Brasileiro S.A.','600','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d4f-72aa-b49f-e220be8d1461','Banco Industrial do Brasil S.A.','604','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d5c-7359-afd8-225eedd29490','Banco VR S.A.','610','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d6a-70f3-a76d-5f54d1836821','Banco Paulista S.A.','611','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d78-7222-80ec-7fbae62c4add','Banco Guanabara S.A.','612','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d85-7352-885e-824a2c084fe2','Omni Banco S.A.','613','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3d92-7313-92df-278affdd9900','Banco Pan S.A.','623','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3da6-731b-9053-fd6788dd3be7','Banco Ficsa S.A.','626','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3dba-7269-a5bd-05a35f656af8','Banco Smartbank S.A.','630','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3dce-73d6-b977-48cda2a132c6','Banco Rendimento S.A.','633','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3ddd-712f-a42c-ae25fa4157b8','Banco Triângulo S.A.','634','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3dea-715f-b289-115f661c24b8','Banco Alvorada S.A.','641','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3df8-7058-b4f3-fd362647c729','Banco Pine S.A.','643','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e0a-7186-826e-b68161787c95','Banco Indusval S.A.','653','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e17-7269-b8de-2e47ea206861','Banco Digimais S.A.','654','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e24-7205-9afa-5ba7326f4336','Banco Votorantim S.A.','655','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e32-72ab-bfba-dcdc086f8e9a','Banco Daycoval S.A.','707','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e3f-7035-96bd-153d01a43f8c','Banco Ourinvest S.A.','712','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e4d-7107-81ce-3f55d5456b79','Banco Citibank S.A.','745','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e5a-7249-a0dd-01bb78659009','Banco Modal S.A.','746','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e6d-705f-a57e-1dc3510c80a5','Banco Rabobank International Brasil S.A.','747','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e7b-7158-a88a-7649c6c58065','Sicredi (Sistema de Crédito Cooperativo)','748','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e8d-7274-a4e2-aff270eff742','Scotiabank Brasil S.A. Banco Múltiplo','751','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3e9a-70ad-8336-5f9fcbe462ef','Banco BNP Paribas Brasil S.A.','752','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3ea8-71ac-9e54-ff6bc330ff18','Bank of America Merrill Lynch Banco Múltiplo S.A.','755','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3eb5-710c-a738-e3e64d89b673','Sicoob (Sistema de Cooperativas de Crédito do Brasil)','756','2026-02-02 13:25:05','2026-02-02 13:25:05');
/*!40000 ALTER TABLE `bancos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `categoria_pai_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` enum('receita','despesa') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categorias_user_id_foreign` (`user_id`),
  KEY `categorias_categoria_pai_id_foreign` (`categoria_pai_id`),
  CONSTRAINT `categorias_categoria_pai_id_foreign` FOREIGN KEY (`categoria_pai_id`) REFERENCES `categorias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categorias_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES ('019c1f2f-eafd-72c1-b99e-b045c22541f1',1,NULL,'Alimentação','despesa','#FF6B35',NULL,'2026-02-02 16:29:19','2026-02-02 19:52:44'),('019c1f3a-1bb4-71c7-a90a-fb3a45646b38',1,'019c1f2f-eafd-72c1-b99e-b045c22541f1','Supermercado','despesa','#FF8C5A',NULL,'2026-02-02 16:40:27','2026-02-02 16:40:27'),('019c1f3a-5a9e-72fd-b80a-fb4da950cf75',1,'019c1f2f-eafd-72c1-b99e-b045c22541f1','Restaurante','despesa','#FF4500',NULL,'2026-02-02 16:40:43','2026-02-02 16:40:43'),('019c1f3a-87eb-709d-95e4-fa2ff2b10924',1,'019c1f2f-eafd-72c1-b99e-b045c22541f1','Lanches','despesa','#FFA07A',NULL,'2026-02-02 16:40:55','2026-02-02 16:40:55'),('019c1f3b-f5d4-71e0-a1c2-e559141ad6c3',1,NULL,'Transporte','despesa','#3A86FF',NULL,'2026-02-02 16:42:29','2026-02-02 16:42:29'),('019c1f3c-a29a-737e-882d-d8775059f5ab',1,'019c1f3b-f5d4-71e0-a1c2-e559141ad6c3','Onibus','despesa','#5A9FFF',NULL,'2026-02-02 16:43:13','2026-02-02 16:43:13'),('019c1f3c-d95f-7113-bd3b-3b25a119e996',1,'019c1f3b-f5d4-71e0-a1c2-e559141ad6c3','Uber','despesa','#1E6FFF',NULL,'2026-02-02 16:43:27','2026-02-02 16:43:27'),('019c1fb1-e113-706d-a977-2a8ad4d33535',1,NULL,'Salário','receita','#2EC4B6',NULL,'2026-02-02 18:51:17','2026-02-02 18:51:17'),('019c1fb2-308e-7314-b921-c6d5762cf1aa',1,NULL,'Moradia','despesa','#8338EC',NULL,'2026-02-02 18:51:37','2026-02-02 18:51:37'),('019c1fb4-4d9c-729b-bfb4-8967e619e42d',1,NULL,'Empréstimo','receita','#FF9800',NULL,'2026-02-02 18:53:55','2026-02-02 18:53:55'),('019c1fb4-ac47-735b-8ad3-e2c6fc08fc16',1,NULL,'Pagamento de Empréstimos','despesa','#F57C00',NULL,'2026-02-02 18:54:20','2026-02-02 18:54:20'),('019c1fb5-a141-730f-b313-e9f0a0004c95',1,'019c1fb4-4d9c-729b-bfb4-8967e619e42d','Empréstimo Recebido - Facio','receita','#FFB74D',NULL,'2026-02-02 18:55:22','2026-02-02 18:55:22'),('019c1fb5-f452-71b8-8ff4-f4f44d262c54',1,'019c1fb4-4d9c-729b-bfb4-8967e619e42d','Empréstimo Recebido - Amigos','receita','#FFA726',NULL,'2026-02-02 18:55:44','2026-02-02 18:55:44'),('019c1fb6-7c25-7201-82ca-4468ca2c2c0a',1,'019c1fb4-ac47-735b-8ad3-e2c6fc08fc16','Pagamento - Facio','despesa','#FF9800',NULL,'2026-02-02 18:56:18','2026-02-02 18:56:18'),('019c1fb6-d42e-7143-86b7-e16ca38f5e7c',1,'019c1fb4-ac47-735b-8ad3-e2c6fc08fc16','Pagamento - Amigos','despesa','#FB8C00',NULL,'2026-02-02 18:56:41','2026-02-02 18:56:41'),('019c1fb7-2068-714b-b85c-7cc34b9b2d63',1,'019c1fb4-ac47-735b-8ad3-e2c6fc08fc16','Juros de Empréstimo','despesa','#E65100',NULL,'2026-02-02 18:57:01','2026-02-02 18:57:01'),('019c1fb9-7197-7001-95d2-894c672e2469',1,NULL,'Assinaturas Digitais','despesa','#9C27B0',NULL,'2026-02-02 18:59:32','2026-02-02 18:59:32'),('019c1fba-019d-70b4-a9f8-c50aa2ab3680',1,'019c1fb9-7197-7001-95d2-894c672e2469','Streaming','despesa','#BA68C8',NULL,'2026-02-02 19:00:09','2026-02-02 19:00:09'),('019c1fdf-aa6d-72b7-b98e-a216a722cb83',1,'019c1fb9-7197-7001-95d2-894c672e2469','Ferramentas Dev','despesa','#8E24AA',NULL,'2026-02-02 19:41:17','2026-02-02 19:41:17'),('019c1fe0-0d4b-71d6-a569-21a48392d7d6',1,'019c1fb9-7197-7001-95d2-894c672e2469','Cloud/Hospedagem','despesa','#6A1B9A',NULL,'2026-02-02 19:41:43','2026-02-02 19:41:43'),('019c1fe0-4baf-708d-8d9c-c6e72644e587',1,'019c1fb9-7197-7001-95d2-894c672e2469','IA e APIs','despesa','#7B1FA2',NULL,'2026-02-02 19:41:59','2026-02-02 19:41:59'),('019c1ff5-d68c-70f4-9b9f-a60528b0ca46',1,'019c1f3b-f5d4-71e0-a1c2-e559141ad6c3','Combustivel','despesa','#5A9FFF',NULL,'2026-02-02 20:05:30','2026-02-02 20:05:30');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conta_bancaria`
--

DROP TABLE IF EXISTS `conta_bancaria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conta_bancaria` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `banco_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nome` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_conta` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `saldo_inicial` decimal(8,2) NOT NULL,
  `saldo_atual` decimal(8,2) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `conta_bancaria_user_id_foreign` (`user_id`),
  KEY `conta_bancaria_banco_id_foreign` (`banco_id`),
  CONSTRAINT `conta_bancaria_banco_id_foreign` FOREIGN KEY (`banco_id`) REFERENCES `bancos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `conta_bancaria_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conta_bancaria`
--

LOCK TABLES `conta_bancaria` WRITE;
/*!40000 ALTER TABLE `conta_bancaria` DISABLE KEYS */;
INSERT INTO `conta_bancaria` VALUES ('019c1e96-47fa-7280-88e9-0baac10fdc6f',1,'019c1e87-3b97-7271-a3f4-1da5446585d8','Conta Nubank','32697897','corrente',0.28,0.28,NULL,'2026-02-02 13:41:31','2026-02-02 13:45:28');
/*!40000 ALTER TABLE `conta_bancaria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lancamentos`
--

DROP TABLE IF EXISTS `lancamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lancamentos` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `categoria_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conta_bancaria_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fatura_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recorrencia_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` enum('receita','despesa') COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` decimal(15,2) NOT NULL,
  `valor_pago` decimal(15,2) NOT NULL DEFAULT '0.00',
  `data_vencimento` date NOT NULL,
  `data_pagamento` date DEFAULT NULL,
  `status` enum('pendente','parcial','pago','recebido','atrasado','cancelado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendente',
  `observacoes` text COLLATE utf8mb4_unicode_ci,
  `anexo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lancamentos_user_id_foreign` (`user_id`),
  KEY `lancamentos_categoria_id_foreign` (`categoria_id`),
  KEY `lancamentos_conta_bancaria_id_foreign` (`conta_bancaria_id`),
  KEY `lancamentos_tipo_index` (`tipo`),
  KEY `lancamentos_status_index` (`status`),
  KEY `lancamentos_data_vencimento_index` (`data_vencimento`),
  KEY `lancamentos_data_pagamento_index` (`data_pagamento`),
  CONSTRAINT `lancamentos_categoria_id_foreign` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`),
  CONSTRAINT `lancamentos_conta_bancaria_id_foreign` FOREIGN KEY (`conta_bancaria_id`) REFERENCES `conta_bancaria` (`id`),
  CONSTRAINT `lancamentos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lancamentos`
--

LOCK TABLES `lancamentos` WRITE;
/*!40000 ALTER TABLE `lancamentos` DISABLE KEYS */;
INSERT INTO `lancamentos` VALUES ('019c29d3-613b-7325-96c1-8d43ee5ce3c9',1,'019c1fb1-e113-706d-a977-2a8ad4d33535','019c1e96-47fa-7280-88e9-0baac10fdc6f',NULL,NULL,'receita','Salário Fevereiro',2353.00,0.00,'2026-02-01',NULL,'pendente',NULL,NULL,NULL,'2026-02-04 18:04:04','2026-02-04 18:04:04');
/*!40000 ALTER TABLE `lancamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_01_23_185808_create_bancos_table',1),(5,'2026_01_23_202220_create_solicitacao_banco_novos_table',1),(6,'2026_01_27_141116_create_roles_table',1),(7,'2026_01_27_142038_create_user_roles_table',1),(8,'2026_01_27_174210_create_permissions_table',1),(9,'2026_01_27_174439_create_permission_roles_table',1),(10,'2026_01_27_183535_adicionar_coluna_de_decisao',1),(11,'2026_01_28_130154_create_conta_bancarias_table',1),(16,'2026_02_02_101333_create_categorias_table',2),(18,'2026_02_02_170139_create_lancamentos_table',3),(19,'2026_02_04_161439_create_baixa_parcials_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_roles`
--

DROP TABLE IF EXISTS `permission_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_roles` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_roles_permission_id_foreign` (`permission_id`),
  KEY `permission_roles_role_id_foreign` (`role_id`),
  CONSTRAINT `permission_roles_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_roles`
--

LOCK TABLES `permission_roles` WRITE;
/*!40000 ALTER TABLE `permission_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  KEY `role_user_user_id_foreign` (`user_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES ('019c1e8a-e787-7044-a03e-f3e3c010e538','019c1e87-3ec6-7100-9de2-650b360f5895',1,'2026-02-02 13:29:05','2026-02-02 13:29:05');
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES ('019c1e87-3ec6-7100-9de2-650b360f5895','Administrador','2026-02-02 13:25:05','2026-02-02 13:25:05'),('019c1e87-3eda-73ce-a08e-e3a13ea6acd0','Cliente','2026-02-02 13:25:05','2026-02-02 13:25:05');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('jtc1VYN7JGA9ve2QkDsB5QpaunnXvMjABww2uxlG',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUlVvWXJmZXBocjEyWXhvcTRtZzdXaXloZ0YyNUNxYXlXZUhzT0x3ZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9jb250YXMtcmVjZWJlciI7czo1OiJyb3V0ZSI7czozNToiYXV0ZW50aWNhZG8uY29udGFzLXJlY2ViZXIubGlzdGFnZW0iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6NDoibWFyeSI7YToxOntzOjU6InRvYXN0IjthOjA6e319fQ==',1770238423);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solicitacao_banco_novo`
--

DROP TABLE IF EXISTS `solicitacao_banco_novo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `solicitacao_banco_novo` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `observacao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `decisao` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `motivo_decisao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `solicitacao_banco_novo_user_id_foreign` (`user_id`),
  CONSTRAINT `solicitacao_banco_novo_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solicitacao_banco_novo`
--

LOCK TABLES `solicitacao_banco_novo` WRITE;
/*!40000 ALTER TABLE `solicitacao_banco_novo` DISABLE KEYS */;
/*!40000 ALTER TABLE `solicitacao_banco_novo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Gustavo de Camargo Campos','contato.wanjalagus@outlook.com.br',NULL,'$2y$12$i7rs/FQB0QYFqNd6DPBhI.itKsy9Si1GkLI39T25WVQ8gb/V31aHK','iaykkf6nsaHz3OkjmpiFjIX8JbgHMcf6ieI2ma4eOGpQIcpK2WT1tNEgreoU','2026-02-02 13:25:55','2026-02-02 13:25:55');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'gestum'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-04 16:54:37
